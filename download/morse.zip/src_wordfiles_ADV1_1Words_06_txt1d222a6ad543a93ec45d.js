"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV1_1Words_06_txt"],{

/***/ "./src/wordfiles/ADV1_1Words_06.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/ADV1_1Words_06.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "interrupt {elsewhere|} \r\n{|interrupt elsewhere} \r\ntypical {marketing|} \r\n{|typical marketing} \r\ntechnology {accuracy|} \r\n{|technology accuracy} \r\ndrawing {dessert|} \r\n{|drawing dessert} \r\nsexuality {shower|} \r\n{|sexuality shower} \r\ncarefully {trailer|} \r\n{|carefully trailer} \r\nbullet {apologize|} \r\n{|bullet apologize} \r\nawareness {exhibition|} \r\n{|awareness exhibition} \r\nlightning {Supreme|} \r\n{|lightning Supreme} \r\npleasure {Canadian|} \r\n{|pleasure Canadian} ";

/***/ })

}]);