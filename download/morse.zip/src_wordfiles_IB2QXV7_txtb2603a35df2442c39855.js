"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2QXV7_txt"],{

/***/ "./src/wordfiles/IB2QXV7.txt":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2QXV7.txt ***!
  \***********************************/
/***/ ((module) => {

module.exports = "GA ES TNX FER CALL\nGE ES TNX FER RPRT\nTNX FER FB RPRT\nSOLID CPI RON\nQTH NR PHOENIX\nQTH PORTLAND\nWX RAIN ES WIND\nWX SUN ES NICE\nRIG FLEX\nRIG QSX\nRIG TEN TEC\nRIG TEN TEC\nRIG BOAT ANCHOR\nANT VERT\nNICE FIST OT\nNICE SIG\nWILL QRT NOW\nTNX FER FB QSO\nGUD DX ES HPE CUAGN SOCHO san  \n";

/***/ })

}]);