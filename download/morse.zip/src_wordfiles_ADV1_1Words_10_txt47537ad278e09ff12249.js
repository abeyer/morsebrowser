"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV1_1Words_10_txt"],{

/***/ "./src/wordfiles/ADV1_1Words_10.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/ADV1_1Words_10.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "numeral {summary |} \r\n{|numeral summary } \r\npretty {peanut|} \r\n{|pretty peanut} \r\nstranger {province|} \r\n{|stranger province} \r\ncasual {doctrine|} \r\n{|casual doctrine} \r\npickup {otherwise|} \r\n{|pickup otherwise} \r\nlightly {knowledge|} \r\n{|lightly knowledge} \r\nencourage {complete|} \r\n{|encourage complete} \r\nrequest {punishment|} \r\n{|request punishment} \r\nconvention {factor|} \r\n{|convention factor} \r\nexceed {against|} \r\n{|exceed against} ";

/***/ })

}]);