"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2ARSKBT2_json"],{

/***/ "./src/wordfiles/IB2ARSKBT2.json":
/*!***************************************!*\
  !*** ./src/wordfiles/IB2ARSKBT2.json ***!
  \***************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"<SK>","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);