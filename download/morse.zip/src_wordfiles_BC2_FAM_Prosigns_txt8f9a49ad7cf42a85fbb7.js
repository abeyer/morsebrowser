"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC2_FAM_Prosigns_txt"],{

/***/ "./src/wordfiles/BC2_FAM_Prosigns.txt":
/*!********************************************!*\
  !*** ./src/wordfiles/BC2_FAM_Prosigns.txt ***!
  \********************************************/
/***/ ((module) => {

module.exports = "<AR> \r\n<SK> \r\n<BT> \r\n<SK> \r\n<BT> \r\n<AR> \r\n<BT> \r\n<AR> \r\n<SK> \r\n<AR> \r\n<SK> \r\n<BT> \r\n";

/***/ })

}]);