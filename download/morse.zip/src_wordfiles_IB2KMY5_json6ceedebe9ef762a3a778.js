"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2KMY5_json"],{

/***/ "./src/wordfiles/IB2KMY5.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB2KMY5.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"kmy","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);