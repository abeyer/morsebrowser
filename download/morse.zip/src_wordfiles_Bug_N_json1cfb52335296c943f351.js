"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Bug_N_json"],{

/***/ "./src/wordfiles/Bug_N.json":
/*!**********************************!*\
  !*** ./src/wordfiles/Bug_N.json ***!
  \**********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"1234567890","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);