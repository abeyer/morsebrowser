"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1UWB3_json"],{

/***/ "./src/wordfiles/IB1UWB3.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1UWB3.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"uw","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);