"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_A_json"],{

/***/ "./src/presets/sets/A.json":
/*!*********************************!*\
  !*** ./src/presets/sets/A.json ***!
  \*********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Flow Rate 1","filename":"POL_1.json"},{"display":"Flow Rate 2","filename":"POL_2.json"},{"display":"Flow Rate 3","filename":"POL_3.json"}]}');

/***/ })

}]);