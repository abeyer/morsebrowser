"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1TIN5_json"],{

/***/ "./src/wordfiles/IB1TIN5.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1TIN5.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"tin","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);