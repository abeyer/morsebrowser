"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV2_1Words_03_txt"],{

/***/ "./src/wordfiles/ADV2_1Words_03.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/ADV2_1Words_03.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "construct {multiple|} \r\n{|construct multiple} \r\nphysical {scenario|} \r\n{|physical scenario} \r\npresumably {Palestinian|} \r\n{|presumably Palestinian} \r\ndistinguish {emotionally|} \r\n{|distinguish emotionally} \r\nlegislator {corporate|} \r\n{|legislator corporate} \r\nparticipant {different|} \r\n{|participant different} \r\nbreakfast {background|} \r\n{|breakfast background} \r\nsignificance {approach|} \r\n{|significance approach} \r\naccurately {moderate|} \r\n{|accurately moderate} \r\nextended {horrible|} \r\n{|extended horrible} ";

/***/ })

}]);