"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_Bi_7_txt"],{

/***/ "./src/wordfiles/INT1_Bi_7.txt":
/*!*************************************!*\
  !*** ./src/wordfiles/INT1_Bi_7.txt ***!
  \*************************************/
/***/ ((module) => {

module.exports = "IRON AND BRASS \r\nBIG AND SMALL \r\nSICK AND TIRED \r\nCUT AND RUN \r\nNOW OR NEVER \r\nWINE AND DINE \r\nINS AND OUTS \r\nNEAT AND TIDY \r\nSALT AND PEPPER \r\nFAST AND FURIOUS \r\n";

/***/ })

}]);