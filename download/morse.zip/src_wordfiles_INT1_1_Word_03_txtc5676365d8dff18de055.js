"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_1_Word_03_txt"],{

/***/ "./src/wordfiles/INT1_1 Word_03.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/INT1_1 Word_03.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "and {prime|} \r\n{|and prime} \r\nhave {brain|} \r\n{|have brain} \r\ncold {star|} \r\n{|cold star} \r\ntie {faint|} \r\n{|tie faint} \r\nyet {mount|} \r\n{|yet mount} \r\nwith {leap|} \r\n{|with leap} \r\npanel {realm|} \r\n{|panel realm} \r\nhouse {study|} \r\n{|house study} \r\nthat {cave|} \r\n{|that cave} \r\nhis {array|} \r\n{|his array} ";

/***/ })

}]);