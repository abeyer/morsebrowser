"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2KMY3_json"],{

/***/ "./src/wordfiles/IB2KMY3.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB2KMY3.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"km","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);