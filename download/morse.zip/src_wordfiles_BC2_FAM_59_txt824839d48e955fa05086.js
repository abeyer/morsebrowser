"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC2_FAM_59_txt"],{

/***/ "./src/wordfiles/BC2_FAM_59.txt":
/*!**************************************!*\
  !*** ./src/wordfiles/BC2_FAM_59.txt ***!
  \**************************************/
/***/ ((module) => {

module.exports = "5 \r\n9 \r\n, \r\n9 \r\n, \r\n5 \r\n, \r\n5 \r\n9 \r\n5 \r\n9 \r\n, \r\n";

/***/ })

}]);