"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2162_json"],{

/***/ "./src/wordfiles/IB2162.json":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2162.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"6","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);