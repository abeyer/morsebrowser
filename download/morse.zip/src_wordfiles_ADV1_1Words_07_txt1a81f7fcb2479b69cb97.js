"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV1_1Words_07_txt"],{

/***/ "./src/wordfiles/ADV1_1Words_07.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/ADV1_1Words_07.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "graduate {operator|} \r\n{|graduate operator} \r\ncruise {normal|} \r\n{|cruise normal} \r\nlittle {witness|} \r\n{|little witness} \r\nhardly {classify|} \r\n{|hardly classify} \r\nsoftware {relatively|} \r\n{|software relatively} \r\nselected {garage|} \r\n{|selected garage} \r\nuncertain {grateful|} \r\n{|uncertain grateful} \r\ncomment {butterfly|} \r\n{|comment butterfly} \r\nleading {Democrat|} \r\n{|leading Democrat} \r\nresult {finally|} \r\n{|result finally} ";

/***/ })

}]);