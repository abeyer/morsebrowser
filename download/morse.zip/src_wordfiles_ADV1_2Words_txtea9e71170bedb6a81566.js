"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV1_2Words_txt"],{

/***/ "./src/wordfiles/ADV1_2Words.txt":
/*!***************************************!*\
  !*** ./src/wordfiles/ADV1_2Words.txt ***!
  \***************************************/
/***/ ((module) => {

module.exports = "\r\nnumeral  provider\r\npretty  matter\r\nstranger  hockey\r\ncasual  tobacco\r\npickup  plenty\r\nlightly  rescue\r\nencourage  ourselves\r\nrequest  steadily\r\nconvention  expect\r\nexceed  content\r\nhazard  private\r\nterror  fashion\r\nOlympics  cousin\r\ntestify  respondent\r\nrailroad  banana\r\nidentity  admission\r\nrocket  season\r\nsupport  episode\r\nextension  crease\r\ncollapse  constitute\r\naction  innovative\r\ntransport  initiate\r\nemploy  scheme\r\ndistract  similarity\r\nlongtime  require\r\nrather  absorb\r\ngovernor  faculty\r\nsurgeon  testing\r\nutility  lifestyle\r\nsettle  casualty\r\ngraduate  picture\r\ncruise  reception\r\nlittle  unique\r\nhardly  stimulate\r\nsoftware  toilet\r\nselected  subtle\r\nuncertain  prisoner\r\ncomment  present\r\nleading  provide\r\nresult  dispute\r\ninterrupt  creative\r\ntypical  homework\r\ntechnology  official\r\ndrawing  likelihood\r\nsexuality  tunnel\r\ncarefully  tolerance\r\nbullet  pregnancy\r\nawareness  bucket\r\nlightning  eighth\r\npleasure  consumer\r\nAfrican  Canadian\r\nconsult  Supreme\r\nexpert  exhibition\r\nneighbor  apologize\r\ncredit  trailer\r\nyourself  shower\r\nvegetable  dessert\r\nemission  accuracy\r\nstring  marketing\r\ndiscipline  elsewhere\r\nnonprofit  finally\r\nedition  Democrat\r\nsuccessful  butterfly\r\nadvocate  grateful\r\nsurely  garage\r\nnature  relatively\r\nplanning  classify\r\nthrough  witness\r\nsocially  normal\r\npoetry  operator\r\nbeauty  gathering\r\nregulator  warmth\r\ncandle  instead\r\ndiversity  healthy\r\nstable  peasant\r\nmetaphor  doorway\r\nmedicine  builder\r\nhonestly  common\r\ninvestor  impressive\r\nsupplier  pioneer\r\ncustody  straighten\r\nmedium  promote\r\nthough  minimum\r\nanyway  legend\r\nbasement  yellow\r\nsuppose  situation\r\nbehavior  sleeve\r\nequation  meanwhile\r\ndirectly  address\r\ngovernment  whenever\r\ncoastal  against\r\nfamiliar  factor\r\nvolume  punishment\r\nfifteen  complete\r\ndefinitely  knowledge\r\nsecond  otherwise\r\npopulation  doctrine\r\nextended  province\r\ncompletely  peanut\r\nCatholic  summary \r\n\r\n\r\n";

/***/ })

}]);