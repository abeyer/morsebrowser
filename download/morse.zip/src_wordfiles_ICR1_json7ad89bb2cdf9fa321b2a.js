"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR1_json"],{

/***/ "./src/wordfiles/ICR1.json":
/*!*********************************!*\
  !*** ./src/wordfiles/ICR1.json ***!
  \*********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"eariotnscl","minWordSize":1,"maxWordSize":1,"practiceSeconds":120}');

/***/ })

}]);