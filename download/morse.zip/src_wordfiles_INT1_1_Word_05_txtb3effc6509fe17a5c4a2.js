"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_1_Word_05_txt"],{

/***/ "./src/wordfiles/INT1_1 Word_05.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/INT1_1 Word_05.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "fully {donor|} \r\n{|fully donor} \r\nshoe {tale|} \r\n{|shoe tale} \r\nlive {cross|} \r\n{|live cross} \r\nskin {porch|} \r\n{|skin porch} \r\nabout {dip|} \r\n{|about dip} \r\nforce {below|} \r\n{|force below} \r\nbill {act|} \r\n{|bill act} \r\ndiet {grade|} \r\n{|diet grade} \r\nboy {toe|} \r\n{|boy toe} \r\ntool {mark|} \r\n{|tool mark} ";

/***/ })

}]);