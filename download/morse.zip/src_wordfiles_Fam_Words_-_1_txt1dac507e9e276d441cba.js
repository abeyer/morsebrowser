"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_Words_-_1_txt"],{

/***/ "./src/wordfiles/Fam_Words - 1.txt":
/*!*****************************************!*\
  !*** ./src/wordfiles/Fam_Words - 1.txt ***!
  \*****************************************/
/***/ ((module) => {

module.exports = "some \r\nthan \r\nin \r\nnow \r\none \r\nback \r\nof \r\nall \r\nup \r\njust \r\nalso \r\nwhat \r\nlike \r\nthen \r\nme \r\nits \r\nmost \r\nafter \r\nother \r\nwould \r\nuse \r\nus \r\nshe \r\nhave \r\nan \r\n";

/***/ })

}]);