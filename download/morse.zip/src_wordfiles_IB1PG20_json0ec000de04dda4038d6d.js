"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1PG20_json"],{

/***/ "./src/wordfiles/IB1PG20.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1PG20.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"ps","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);