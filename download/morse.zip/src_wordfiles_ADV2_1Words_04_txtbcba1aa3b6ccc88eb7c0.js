"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV2_1Words_04_txt"],{

/***/ "./src/wordfiles/ADV2_1Words_04.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/ADV2_1Words_04.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "theology {actively|} \r\n{|theology actively} \r\nfundamental {credibility|} \r\n{|fundamental credibility} \r\nconviction {straight|} \r\n{|conviction straight} \r\ninterfere {activist|} \r\n{|interfere activist} \r\nprospect {population|} \r\n{|prospect population} \r\nbuilding {abortion|} \r\n{|building abortion} \r\nelectronic {elevator|} \r\n{|electronic elevator} \r\npromising {impression|} \r\n{|promising impression} \r\nprotective {drinking|} \r\n{|protective drinking} \r\nabsolute {policeman|} \r\n{|absolute policeman} ";

/***/ })

}]);