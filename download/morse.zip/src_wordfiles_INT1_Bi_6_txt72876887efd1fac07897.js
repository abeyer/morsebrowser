"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_Bi_6_txt"],{

/***/ "./src/wordfiles/INT1_Bi_6.txt":
/*!*************************************!*\
  !*** ./src/wordfiles/INT1_Bi_6.txt ***!
  \*************************************/
/***/ ((module) => {

module.exports = "PEACE AND QUIET \r\nJACK AND JILL \r\nEAST OR WEST \r\nHIGH AND DRY \r\nUP AND DOWN \r\nSOONER OR LATER \r\nHUFF AND PUFF \r\nDOWN AND OUT \r\nOFF AND ON \r\nFACTS AND FIGURES \r\n";

/***/ })

}]);