"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2ZJ1_json"],{

/***/ "./src/wordfiles/IB2ZJ1.json":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2ZJ1.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"z","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);