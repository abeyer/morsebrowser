"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1TIN1_json"],{

/***/ "./src/wordfiles/IB1TIN1.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1TIN1.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"t","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);