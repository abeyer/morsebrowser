"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Bug_LN_json"],{

/***/ "./src/wordfiles/Bug_LN..json":
/*!************************************!*\
  !*** ./src/wordfiles/Bug_LN..json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);