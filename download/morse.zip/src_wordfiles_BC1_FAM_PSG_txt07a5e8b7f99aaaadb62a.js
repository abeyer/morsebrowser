"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC1_FAM_PSG_txt"],{

/***/ "./src/wordfiles/BC1_FAM_PSG.txt":
/*!***************************************!*\
  !*** ./src/wordfiles/BC1_FAM_PSG.txt ***!
  \***************************************/
/***/ ((module) => {

module.exports = "P \r\nS \r\nG \r\nS \r\nG \r\nP \r\nG \r\nP \r\nS \r\nP \r\nS \r\nG \r\n";

/***/ })

}]);