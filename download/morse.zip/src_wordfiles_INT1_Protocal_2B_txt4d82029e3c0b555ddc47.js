"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_Protocal_2B_txt"],{

/***/ "./src/wordfiles/INT1_Protocal_2B.txt":
/*!********************************************!*\
  !*** ./src/wordfiles/INT1_Protocal_2B.txt ***!
  \********************************************/
/***/ ((module) => {

module.exports = "OK JOEY FB ES TNX FER RPRT \r\nRIG FT 450D ES PWR 50W \r\nANT VERTICAL UP 60 FT \r\nWX FOGGY ES TEMP 45F \r\nOK HW? AR KU6X DE WR5LC K \r\nOK ANN TNX FER INFO \r\nRIG TS 590SG ES PWR 100W \r\nANT WINDOM UP 20 FT \r\nWX FOGGY ES TEMP 67F \r\nOK ANN HW? AR WR5LC DE KU6X K ";

/***/ })

}]);