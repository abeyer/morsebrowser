"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2402_json"],{

/***/ "./src/wordfiles/IB2402.json":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2402.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"0","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);