"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Bug_P_json"],{

/***/ "./src/wordfiles/Bug_P.json":
/*!**********************************!*\
  !*** ./src/wordfiles/Bug_P.json ***!
  \**********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":".,/?","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);