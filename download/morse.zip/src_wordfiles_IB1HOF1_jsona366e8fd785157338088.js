"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1HOF1_json"],{

/***/ "./src/wordfiles/IB1HOF1.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1HOF1.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"h","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);