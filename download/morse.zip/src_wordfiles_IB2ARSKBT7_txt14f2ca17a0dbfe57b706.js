"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2ARSKBT7_txt"],{

/***/ "./src/wordfiles/IB2ARSKBT7.txt":
/*!**************************************!*\
  !*** ./src/wordfiles/IB2ARSKBT7.txt ***!
  \**************************************/
/***/ ((module) => {

module.exports = "NICE TO CU AGN\nOP RIN\nANT DIPOLE UP IN TREE\nRETIRED AIR FORCE\nRIG TEN TEC\nTU FER INFO\nHPE CUAGN DR BOB\nHPE CUAGN DR HIRO san\n";

/***/ })

}]);