"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV2_1Words_05_txt"],{

/***/ "./src/wordfiles/ADV2_1Words_05.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/ADV2_1Words_05.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "interior {academic|} \r\n{|interior academic} \r\nhistorical {selected|} \r\n{|historical selected} \r\nassignment {photographer|} \r\n{|assignment photographer} \r\nincluding {equation|} \r\n{|including equation} \r\nexercise {intensity|} \r\n{|exercise intensity} \r\neveryone {membership|} \r\n{|everyone membership} \r\nCatholic {normally|} \r\n{|Catholic normally} \r\nincrease {domestic|} \r\n{|increase domestic} \r\nexternal {honestly|} \r\n{|external honestly} \r\ngrateful {psychologist|} \r\n{|grateful psychologist} ";

/***/ })

}]);