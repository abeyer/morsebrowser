"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC1_P_Eval_S_txt"],{

/***/ "./src/wordfiles/BC1_P_Eval_S.txt":
/*!****************************************!*\
  !*** ./src/wordfiles/BC1_P_Eval_S.txt ***!
  \****************************************/
/***/ ((module) => {

module.exports = "PETER WOLF HOWLED WHEN THE CUB BEAR ROARS AND SINGS \r\n\r\nTHE BIG WHITE WET BEAR COULD FIND THE FOUR PIE PANS \r\n\r\nBOBS WET GOLF CLUB SNAPPED FRESH WATER INTO HER \r\n\r\nDAN SPUN FOUR GREAT BROWN CUPS FULL OF PAINT TO HER \r\n\r\nPAGE RUNS TO THE LARGE OLD WHARF TO GRASP A NICE ROBE \r\n\r\nFILL BOBS NICE BROWN PEN WITH PAINT AND RUN DRIPPING \r\n\r\nPAGE WENT TO THE PIRATES WHARF AND BOUGHT BLUE CUPS \r\n\r\nFOUR BEARS SNAG FRESH PIES AND GLIDE ON COLD SNOW \r\n\r\nBOB SAW THE FLOWERS WERE NICE WHILE DAN CUT GRAPES \r\n\r\nPUG PAINTS HER DIPOLE IN THE RAIN WHILE BOB PATS HIS FACE ";

/***/ })

}]);