"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT2_1_Word_05_txt"],{

/***/ "./src/wordfiles/INT2_1 Word_05.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/INT2_1 Word_05.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "rest {await|} \r\n  {|rest await} \r\noccur {hope|} \r\n  {|occur hope} \r\never {welcome|} \r\n  {|ever welcome} \r\nprofit {cloth|} \r\n  {|profit cloth} \r\ncentral {excited|} \r\n  {|central excited} \r\nnurse {cabin|} \r\n  {|nurse cabin} \r\nwell {blue|} \r\n  {|well blue} \r\nscream {clean|} \r\n  {|scream clean} \r\nmystery {rapid|} \r\n  {|mystery rapid} \r\nmoon {lawsuit|} \r\n  {|moon lawsuit} ";

/***/ })

}]);