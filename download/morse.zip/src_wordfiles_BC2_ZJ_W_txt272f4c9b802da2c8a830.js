"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC2_ZJ_W_txt"],{

/***/ "./src/wordfiles/BC2_ZJ_W.txt":
/*!************************************!*\
  !*** ./src/wordfiles/BC2_ZJ_W.txt ***!
  \************************************/
/***/ ((module) => {

module.exports = "ZOO \r\nJIG \r\nJET \r\nJOT \r\nJOY \r\nFEZ \r\nJAM \r\nJOB \r\nBIT \r\nFIG \r\nONE \r\nHAD \r\nNOT \r\nEAR \r\nBUZZ \r\nCHEZ \r\nDOJO \r\nAJAR \r\nJOKE \r\nHOPE \r\nJACK \r\nJILL \r\nCOST \r\nBEEN \r\nBURN \r\nTREE \r\nHALF \r\nSNOW \r\nBOAT \r\nLOST \r\nSLIP \r\nWIND \r\nTHIS \r\nRAIL \r\nTHEIR \r\nZEBRA \r\nSTEEL \r\nABUZZ \r\nAMAZE \r\nSHINE \r\nCOAST \r\nBOARD \r\nORGAN \r\nANGER \r\nPRINT \r\nFLOOR \r\nLEAST \r\nFIRST \r\nGREAT \r\nSTILL \r\n\r\n";

/***/ })

}]);