"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB21610_json"],{

/***/ "./src/wordfiles/IB21610.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB21610.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"16.uwb","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);