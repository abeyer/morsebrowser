"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_HOF10_txt"],{

/***/ "./src/wordfiles/HOF10.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/HOF10.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "COD DOC OLD LOG POD DOG CHOPS COLD FLOPS GOD CLOGS GOLF SHOP DOCS GOLD GOSH POOF HOLD FOLD HOPS DOGS SOLD FOG SCOLD\n";

/***/ })

}]);