"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1TIN3_json"],{

/***/ "./src/wordfiles/IB1TIN3.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1TIN3.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"ti","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);