"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1LCD4_json"],{

/***/ "./src/wordfiles/IB1LCD4.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1LCD4.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"d","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);