"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2C2_txt"],{

/***/ "./src/wordfiles/IB2C2.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/IB2C2.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "<AR> <BT> <SK> 599 73 5NN ABT AGE AGN AM ANT B4 BEEN BK BUG C CALL CFM CLEAR CPI CPY CQ CU CUAGN CUL CW DE DN DR DX EL ES FB FER FM FT GA GE GM GN GND GUD HAM HI HPE HR HW HW? INFO K OK OM OP OT PSE PWR QRM QRN QRP QRQ QRS QRT QRZ QSB QSL QSO QSY QTH R RAIN RFI RIG RPRT RPT RR RST RX SIG SKED SOLID SRI SSB SUN T TEMP TKS TNX TU TX U UP UR VERT VY W WID WIND WPM WUD WX YAGI YRS\n";

/***/ })

}]);