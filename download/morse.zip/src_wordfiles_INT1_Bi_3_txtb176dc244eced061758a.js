"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_Bi_3_txt"],{

/***/ "./src/wordfiles/INT1_Bi_3.txt":
/*!*************************************!*\
  !*** ./src/wordfiles/INT1_Bi_3.txt ***!
  \*************************************/
/***/ ((module) => {

module.exports = "ALL OR NOTHING \r\nLIFE OR DEATH \r\nDOOM AND GLOOM \r\nYOUNG AND OLD \r\nOUT AND ABOUT \r\nYEAR AND MONTH \r\nNOW AND AGN \r\nOVER AND OUT \r\nGRIN AND BEAR IT \r\nONE OR TWO \r\n";

/***/ })

}]);