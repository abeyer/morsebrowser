"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_B1_json"],{

/***/ "./src/wordfiles/B1.json":
/*!*******************************!*\
  !*** ./src/wordfiles/B1.json ***!
  \*******************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);