"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2598_txt"],{

/***/ "./src/wordfiles/IB2598.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/IB2598.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "N5DR AB5TN K5EA KB9YN N9CD WB9FO WB5UWB WB5HOF AB9REA AA5TIN AC9LCD AB9LCD WB9EAR N5FOH N9CDL\n";

/***/ })

}]);