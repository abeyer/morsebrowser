"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_Words_-_4_txt"],{

/***/ "./src/wordfiles/Fam_Words - 4.txt":
/*!*****************************************!*\
  !*** ./src/wordfiles/Fam_Words - 4.txt ***!
  \*****************************************/
/***/ ((module) => {

module.exports = "time \r\nwho \r\ntheir \r\nwell \r\ndo \r\neven \r\nor \r\nbut \r\nthat \r\nwhich \r\ngive \r\ntwo \r\nso \r\nhim \r\nthis \r\nyear \r\nyour \r\nthese \r\nwant \r\nthey \r\nmake \r\nand \r\nnew \r\nbecause \r\ntake\r\n";

/***/ })

}]);