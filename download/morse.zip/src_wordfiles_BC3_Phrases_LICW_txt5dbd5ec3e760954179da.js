"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC3_Phrases_LICW_txt"],{

/***/ "./src/wordfiles/BC3_Phrases_LICW.txt":
/*!********************************************!*\
  !*** ./src/wordfiles/BC3_Phrases_LICW.txt ***!
  \********************************************/
/***/ ((module) => {

module.exports = "UR 599 599 \r\nQTH {TX|texas} {TX|texas} \r\nNAME TOM TOM \r\nLICW {NR|number} 450I 450I \r\n{<BT>|}\r\nUR {459|4 5 9} {459|4 5 9} \r\nQTH AZ AZ \r\nNAME MIKE MIKE \r\nLICW {NR|number} 250A 250A \r\n{<BT>|}\r\nUR 5NN 5NN \r\nQTH {OH|ohio} {OH|ohio} \r\nNAME JOE JOE \r\nLICW {NR|number} 2241 2241 \r\n{<BT>|}\r\nUR {579|5 7 9} {579|5 7 9} \r\nQTH KS KS\r\nNAME Ann Ann\r\nLICW {NR|number} 1469 1469 \r\n";

/***/ })

}]);