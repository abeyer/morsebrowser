"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR2_txt"],{

/***/ "./src/wordfiles/ICR2.txt":
/*!********************************!*\
  !*** ./src/wordfiles/ICR2.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "OR\nCA\nNE\nIA\nAR\nLA\nIL\nAL\nIN\nTN\nNC\nSC\nRI\nCT\n";

/***/ })

}]);