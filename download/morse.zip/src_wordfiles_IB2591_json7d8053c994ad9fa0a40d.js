"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2591_json"],{

/***/ "./src/wordfiles/IB2591.json":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2591.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"5","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);