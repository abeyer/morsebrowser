"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT2_1_Word_04_txt"],{

/***/ "./src/wordfiles/INT2_1 Word_04.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/INT2_1 Word_04.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "judge {burst|} \r\n  {|judge burst} \r\nscore {lightly|} \r\n  {|score lightly} \r\ndecade {hold|} \r\n  {|decade hold} \r\ngame {porch|} \r\n  {|game porch} \r\nheavily {senior|} \r\n  {|heavily senior} \r\naccuse {German|} \r\n  {|accuse German} \r\nsave {vitamin|} \r\n  {|save vitamin} \r\nearth {sell|} \r\n  {|earth sell} \r\nlower {execute|} \r\n  {|lower execute} \r\nsuch {knee|} \r\n  {|such knee} ";

/***/ })

}]);