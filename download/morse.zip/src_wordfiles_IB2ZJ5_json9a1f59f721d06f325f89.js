"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2ZJ5_json"],{

/***/ "./src/wordfiles/IB2ZJ5.json":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2ZJ5.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"zj/","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);