"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC2_28_W_txt"],{

/***/ "./src/wordfiles/BC2_28_W.txt":
/*!************************************!*\
  !*** ./src/wordfiles/BC2_28_W.txt ***!
  \************************************/
/***/ ((module) => {

module.exports = "OIL \r\nWIN \r\nAGO \r\nFUN \r\nACT \r\nLOG \r\nBAD \r\nFOR \r\nBED \r\nPUT \r\nSAW \r\nBIG \r\nHIS \r\nHOPE  \r\nPAGE \r\nIRON \r\nTRIP \r\nBOAT \r\nWOOD \r\nLIST \r\nREAL \r\nONCE \r\nGIRL \r\nHOLD \r\nJUST \r\nSTAR \r\nRING \r\nLOST \r\nSING \r\nANGER \r\nBOARD \r\nSCALE \r\nWATCH \r\nSINCE \r\nOFTEN \r\nLARGE \r\nSLEEP \r\nCOAST \r\nEARTH \r\nCHIEF \r\nOFFER \r\nPOUND \r\nLIGHT \r\nSTATE \r\nRANGE \r\nTHEIR \r\nSTEEL \r\nLEARN \r\nSHINE \r\nPIECE \r\n\r\n";

/***/ })

}]);