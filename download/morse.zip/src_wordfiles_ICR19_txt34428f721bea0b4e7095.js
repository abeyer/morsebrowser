"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR19_txt"],{

/***/ "./src/wordfiles/ICR19.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/ICR19.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "OK \ndry \nold \nmom \nrow \nlet \ngod \nkid \nmix \nwho \nby \nsee \nbye \nart \ntry \njam \ncar \nbar \ngas \nfry \nfun \nfix \ndo \nTV \ntie \nfar \nsun \nbuy \nday \nraw \ntip \nhe \nlab \nweb \noff \nyet \nI \npet \nin \nshe \nnut \njoy \nsad \npig \nlay \nair \nwar \nhot \nodd \nyes \nmad \nflu \nor \ncan \ncow \nour \nbe \noil \nboy \ntea \nbid \nto \non \nwin \nof \nuse \nits \ndad \nsex \nadd \nbag \nhow \nfor \nice \ntwo \npot \nkey \nten \nbig \nyou \negg \nall \nman \nCD \nhi \nit \ndig \nput \nbed \nme \nfur \nso \nbit \nbeg \nact \nad \narm \npop \nshy \nbad \nhis \nleg \nand \nnow \ncry \ncap \nred \njob \ndog \nage \near \nlaw \nnor \nban \neat \nmy \npay \nski \ncut \nhim \ngap \ngun \nrid \nsum \nsix \nwe \nrun \nvia \nper \naid \ntoe \nbee \nsea \nson \nmud \nfly \ngym \nat \nask \nlow \nton \nah \nan \napp \nout \nset \ntop \nnet \nDVD \nany \nend \nnew \nget \npin \nbus \nown \nguy \nfan \nfat \nus \neye \ngo \ndie \ncup \nfit \nas \nway \none \nbut \nup \nsky \nbet \ndue \ntax \npan \nif \nbox \nlip \nlie \nhat \nrub \nowe \na \ncat \ntoy \nago \nhey \ntoo \nhit \nwow \nvan \nill \nfew \nlot \nher \npen \nmap \nwet \nno \nMay \nwhy \nsir \nfee \nthe \noh \nnot \nsay \naim \nsit \n\n";

/***/ })

}]);