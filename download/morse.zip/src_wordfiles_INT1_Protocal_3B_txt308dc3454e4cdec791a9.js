"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_Protocal_3B_txt"],{

/***/ "./src/wordfiles/INT1_Protocal_3B.txt":
/*!********************************************!*\
  !*** ./src/wordfiles/INT1_Protocal_3B.txt ***!
  \********************************************/
/***/ ((module) => {

module.exports = "OK BARB GUD CPY \r\nBEEN HAM 23 YRS \r\nAGE HR 66 YRS \r\nWRK AS TEACHER \r\nOK BARB HW? AR N9RL DE WT6UBP K \r\nOK ROB GUD CPY \r\nBEEN HAM 24 YRS \r\nAGE HR 55 YRS \r\nWRK AS SCIENTIST \r\nOK ROB HW? AR WT6UBP DE N9RL K ";

/***/ })

}]);