"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC2_PS_W_txt"],{

/***/ "./src/wordfiles/BC2_PS_W.txt":
/*!************************************!*\
  !*** ./src/wordfiles/BC2_PS_W.txt ***!
  \************************************/
/***/ ((module) => {

module.exports = "AND \r\nLIE \r\nOFF \r\nRAN \r\nBAD \r\nNOT \r\nCOW \r\nFAIR \r\nSTAR \r\nCOOL \r\nWIND \r\nFEET \r\nDEAR \r\nTUBE \r\nPULL \r\nRICH \r\nBLUE \r\nCASE \r\nHAND \r\nSNOW \r\nHUGE \r\nPAST \r\nLIST \r\nSONG \r\nGREW \r\nEASE \r\nRISE \r\nFIRE \r\nLAST \r\nWISH \r\nWORD \r\nSAFE \r\nNIGHT \r\nBEGIN \r\nTRADE \r\nGROUP \r\nWHILE \r\nCOLOR \r\nSCORE \r\nPLACE \r\nENTER \r\nBROAD \r\nAFTER \r\nUNDER \r\nLEARN \r\nEIGHT \r\nWATER \r\nSHELL \r\nSTEAD \r\nSHEET \r\n\r\n";

/***/ })

}]);