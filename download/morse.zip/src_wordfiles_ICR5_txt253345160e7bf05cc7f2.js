"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR5_txt"],{

/***/ "./src/wordfiles/ICR5.txt":
/*!********************************!*\
  !*** ./src/wordfiles/ICR5.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "A\nI\nAT\nIT\nNO\nTO\nAS\nSO\nOR\nAN\nON\nIN\nIS\nANT\nTOE\nONE\nRAT\nSAT\nEAT\nSIT\nCAR\nACE\nCAT\nOAR\nSET\nARE\nSEE\nACT\nTAN\nRAN\nEEL\nNOR\nTIN\nATE\nCAN\nOIL\nILL\nLOT\nCOT\nNOT\nTEN\nLIE\nALL\nITS\nLATE\nTORN\nEARN\nSAIL\nCOIN\nTALE\nRARE\nLOST\nTOOL\nROLL\nCOOT\nSOLE\nSTAN\nASIA\nROSE\nLOSE\nACRE\nONCE\nTONE\nLESS\nTEST\nCATS\nSORT\nLACE\nNEAR\nROOT\nCENT\nRATS\nCANT\nREST\nSLOT\nLOON\nEATS\nNEAT\nELSE\nALSO\nTILT\nCORE\nLETS\nLAST\nCOST\nSOOT\nSINE\nRENT\nISNT\nIOTA\nNOON\nACES\nNOTE\nCARS\nCOAT\nREEL\nCOAL\nEASE\nSARA\nCONE\nIRON\nRACE\nRISE\nCASE\nSOIL\nNICE\nSEEN\nSORE\nTELL\nSCAN\nTIRE\nRANT\nSELL\nCOOL\nNEON\nLEAN\nTOES\nLINE\nCORN\nOATS\nAREA\nSEAL\nSOON\nCITE\nOARS\nREAR\nTOSS\nLION\nTALL\nTART\nCOIL\nNOSE\nLOTS\nSALE\nSANE\nTENT\nLONE\nCARE\nRAIL\nCANE\nTEAR\nTREE\nTOTE\nCANS\nLOAN\nLENS\nLIST\nSEAT\nSTAR\nRAIN\nNAIL\nROAR\nREAL\nRIOT\nTAIL\n\n";

/***/ })

}]);