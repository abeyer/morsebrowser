"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2ZJ2_json"],{

/***/ "./src/wordfiles/IB2ZJ2.json":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2ZJ2.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"j","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);