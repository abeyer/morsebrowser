"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_QSO2_txt"],{

/***/ "./src/wordfiles/INT1_QSO2.txt":
/*!*************************************!*\
  !*** ./src/wordfiles/INT1_QSO2.txt ***!
  \*************************************/
/***/ ((module) => {

module.exports = "CQ CQ DE KA5G KA5G K \r\nKA5G DE KJ7L KJ7L K \r\nKJ7L DE KA5G \r\nGE ES TNX FER CALL \r\nUR RST 579 579 \r\nQTH SAN DIEGO, CA SAN DIEGO, CA \r\nNAME SKIP SKIP \r\nOK HW? KJ7L DE KA5G K \r\nKA5G DE KJ7L \r\nGE ES TNX FER RPRT \r\nUR RST 599 5NN \r\nQTH FAYETTEVILLE, NC FAYETTEVILLE, NC \r\nNAME CONNER CONNER \r\nOK HW? KA5G DE KJ7L K \r\nOK CONNER FB ES TNX FER RPRT \r\nRIG FT 891 ES PWR 100W \r\nANT BEAM UP 30 FT \r\nWX PARTLY CLOUDY ES TEMP 66F \r\nOK HW? KJ7L DE KA5G K \r\nOK SKIP TNX FER INFO \r\nRIG IC 705 ES PWR 250W \r\nANT INVERTED L UP 80 FT \r\nWX CLOUDY ES TEMP 44F \r\nOK SKIP HW? KA5G DE KJ7L K \r\nOK CONNER GUD CPY \r\nBEEN HAM 4 YRS \r\nAGE HR 27 YRS \r\nWRK AS TRUCK DRIVER \r\nOK CONNER HW? KJ7L DE KA5G K \r\nOK SKIP GUD CPY \r\nBEEN HAM 53 YRS \r\nAGE HR 75 YRS \r\nWRK AS FARMER \r\nOK SKIP HW? KA5G DE KJ7L K \r\nOK CONNER TNX FER FB QSO \r\nES HP CUAGN 73 \r\nKJ7L DE KA5G TU SK \r\nOK SKIP TNX FER FB QSO \r\nES HP CUAGN 73 ";

/***/ })

}]);