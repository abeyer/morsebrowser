"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_B2_PRO_QSO_txt"],{

/***/ "./src/wordfiles/B2_PRO_QSO.txt":
/*!**************************************!*\
  !*** ./src/wordfiles/B2_PRO_QSO.txt ***!
  \**************************************/
/***/ ((module) => {

module.exports = "OP ROB <BT> \r\nRIG TEN TEC <BT> \r\nTU FER INFO <BT> \r\nNICE TO CU AGN <BT> \r\nGOT TO GO NOW <SK> \r\nHPE CUL OM <AR> \r\nRETIRED AIR FORCE <BT> \r\nHPE CUAGN DR BOB <AR> \r\nSO BTU FER RPRT <AR> \r\nANT DIPOLE UP IN TREE <BT> \r\nGA ES TU FER CALL<BT> \r\nUR SIG IS GUD IN PLANO FL<BT> \r\nOP HR RON <BT> \r\nSO HW COPI <AR> ";

/***/ })

}]);