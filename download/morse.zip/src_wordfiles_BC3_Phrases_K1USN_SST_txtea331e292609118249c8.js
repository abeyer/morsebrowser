"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC3_Phrases_K1USN_SST_txt"],{

/***/ "./src/wordfiles/BC3_Phrases_K1USN_SST.txt":
/*!*************************************************!*\
  !*** ./src/wordfiles/BC3_Phrases_K1USN_SST.txt ***!
  \*************************************************/
/***/ ((module) => {

module.exports = "{N1CC|N 1 C C} GA TOM {TX|texas} \r\n{<BT>|}  \r\n{N5AT|n 5 a t} GM SPENCER MA \r\n{<BT>|}  \r\n{KA9ZM|K A 9 Z M} GE FAITH IA \r\n{<BT>|}  \r\nA5BR  GE JAN CO \r\n{<BT>|}  \r\n{WW8TRL|W W 8 T R L} GM  {MAXINE|maxine} UT \r\n{<BT>|}  \r\nN8VK GE  DARRYL MO \r\n{<BT>|}  \r\nN0UIP GA  NICHOLE NE \r\n{<BT>|}  \r\nA0QC GE  CHAD MD \r\n{<BT>|}  \r\n{AS6ZEJ|A S 6 Z E J} GA  JOHNIE NE \r\n{<BT>|}  \r\nKD5J GE  VERA NC \r\n";

/***/ })

}]);