"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Bug_L_json"],{

/***/ "./src/wordfiles/Bug_L.json":
/*!**********************************!*\
  !*** ./src/wordfiles/Bug_L.json ***!
  \**********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"abcdefghijklmnopqrstuvwxyz","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);