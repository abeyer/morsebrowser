"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1UWB2_json"],{

/***/ "./src/wordfiles/IB1UWB2.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1UWB2.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"w","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);