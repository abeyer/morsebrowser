"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_1_Word_09_txt"],{

/***/ "./src/wordfiles/INT1_1 Word_09.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/INT1_1 Word_09.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "off {lead|} \r\n{|off lead} \r\nlot {ash|} \r\n{|lot ash} \r\ntip {camp|} \r\n{|tip camp} \r\ntrial {dumb|} \r\n{|trial dumb} \r\nlimb {unity|} \r\n{|limb unity} \r\nplead {male|} \r\n{|plead male} \r\ngiven {rise|} \r\n{|given rise} \r\ncup {ride|} \r\n{|cup ride} \r\nmask {proud|} \r\n{|mask proud} \r\nreal {thumb|} \r\n{|real thumb} ";

/***/ })

}]);