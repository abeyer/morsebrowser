"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT2_1_Word_06_txt"],{

/***/ "./src/wordfiles/INT2_1 Word_06.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/INT2_1 Word_06.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "coach {year|} \r\n  {|coach year} \r\nquickly {media|} \r\n  {|quickly media} \r\nextent {advance|} \r\n  {|extent advance} \r\nphoto {outside|} \r\n  {|photo outside} \r\nleading {body|} \r\n  {|leading body} \r\nmayor {also|} \r\n  {|mayor also} \r\ntruck {prime|} \r\n  {|truck prime} \r\nmajor {supply|} \r\n  {|major supply} \r\nlibrary {target|} \r\n  {|library target} \r\nrequest {create|} \r\n  {|request create} ";

/***/ })

}]);