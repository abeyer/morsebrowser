"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2C3_txt"],{

/***/ "./src/wordfiles/IB2C3.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/IB2C3.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "W2LCW DE K2UPS GE ES TNX FER CALL\t\nUR RST 599 5NN\nQTH LONG ISLAND, NY LONG ISLAND, NY\nNAME RICH RICH\nOK HW? <AR> W2LCW DE K2UPS\n";

/***/ })

}]);