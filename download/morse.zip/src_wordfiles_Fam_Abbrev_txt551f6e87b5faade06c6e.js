"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_Abbrev_txt"],{

/***/ "./src/wordfiles/Fam_Abbrev.txt":
/*!**************************************!*\
  !*** ./src/wordfiles/Fam_Abbrev.txt ***!
  \**************************************/
/***/ ((module) => {

module.exports = "599  73  5NN  ABT  AGN  ANT  B4  BCNU  CFM  CPI  CPY  CQ  CU  CUAGN  CUL  CW  DE  DX  ES  FB FER  FT  GA  GE  GM  GN  GUD  HR  HW  HW?  PSE  PWR  RPRT  RPT  RST  RX  SIG  SKED  SRI  TEMP  TKS  TNX   TU  TX  UR  VERT  VY  WID  WUD  WX  YRS ";

/***/ })

}]);