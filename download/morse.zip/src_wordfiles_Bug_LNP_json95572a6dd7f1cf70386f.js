"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Bug_LNP_json"],{

/***/ "./src/wordfiles/Bug_LNP.json":
/*!************************************!*\
  !*** ./src/wordfiles/Bug_LNP.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"abcdefghijklmnopqrstuvwxyz1234567890.,?/","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);