"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC2_73_W_txt"],{

/***/ "./src/wordfiles/BC2_73_W.txt":
/*!************************************!*\
  !*** ./src/wordfiles/BC2_73_W.txt ***!
  \************************************/
/***/ ((module) => {

module.exports = "CAR \r\nBIT \r\nDOG \r\nCAT \r\nCOW \r\nTHE \r\nDAD \r\nNOT \r\nOWN \r\nSIT \r\nFOR \r\nDIE \r\nBIG \r\nHELD \r\nPASS \r\nSHOP \r\nTELL \r\nSOON \r\nSOFT \r\nFIND \r\nPORT \r\nCOST \r\nLEFT \r\nFEAR \r\nFISH \r\nTHUS \r\nCOLD \r\nBLOW \r\nINCH \r\nBOAT \r\nSAID \r\nREAD \r\nFELT \r\nIDEA \r\nWIFE \r\nBALL \r\nWELL \r\nWAIT \r\nNEED \r\nSCALE \r\nALLOW \r\nOFTEN \r\nGRAND \r\nSHELL \r\nSTOOD \r\nSHALL \r\nBEGAN \r\nCOUNT \r\nTHERE \r\nAGAIN \r\n\r\n";

/***/ })

}]);