"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC3_Phrases_SKCC_WES_txt"],{

/***/ "./src/wordfiles/BC3_Phrases_SKCC_WES.txt":
/*!************************************************!*\
  !*** ./src/wordfiles/BC3_Phrases_SKCC_WES.txt ***!
  \************************************************/
/***/ ((module) => {

module.exports = "UR 599 599 LA LA \r\nNAME ROBERT ROBERT \r\nSKCC {NR|number} {3169|3 1 6 9} {3169|3 1 6 9} BK \r\n{<BT>|} \r\nUR {459|4 5 9} {459|4 5 9} {GA|georga} {GA|georga} \r\nNAME WILLIAM WILLIAM \r\nSKCC {NR|number} {1994|1 9 9 4} {1994|1 9 9 4} BK \r\n{<BT>|} \r\nUR {559|5 5 9} {559|5 5 9} {TX|texas} {TX|texas} \r\nNAME TOM TOM \r\nSKCC {NR|number} {22145|2 2 1 4 5} {22145|2 2 1 4 5} BK \r\n{<BT>|} \r\nUR {359|3 5 9} {359|3 5 9} KY KY \r\nNAME CORA CORA \r\nSKCC {NR|number} {4332|4 3 3 2} {4332|4 3 3 2} BK \r\n{<BT>|} \r\nUR 5NN 5NN WI WI \r\nNAME SARA SARA \r\nSKCC {NR|number} {8526|8 5 2 6} {8526|8 5 2 6} BK \r\n{<BT>|} \r\nUR {559|5 5 9} {559|5 5 9} IA IA \r\nNAME DALE DALE \r\nSKCC {NR|number} {5260|5 2 6 0} {5260|5 2 6 0} BK \r\n";

/***/ })

}]);