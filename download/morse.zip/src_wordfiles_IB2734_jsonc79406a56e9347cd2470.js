"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2734_json"],{

/***/ "./src/wordfiles/IB2734.json":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2734.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"?","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);