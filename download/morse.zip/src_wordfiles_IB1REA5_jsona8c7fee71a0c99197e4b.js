"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1REA5_json"],{

/***/ "./src/wordfiles/IB1REA5.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1REA5.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"rea","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);