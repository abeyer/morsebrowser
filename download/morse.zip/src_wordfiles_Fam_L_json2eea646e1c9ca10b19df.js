"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_L_json"],{

/***/ "./src/wordfiles/Fam_L.json":
/*!**********************************!*\
  !*** ./src/wordfiles/Fam_L.json ***!
  \**********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"ABCDEFGHIJKLMNOPQRSTUVWXYZ","minWordSize":1,"maxWordSize":1,"practiceSeconds":120}');

/***/ })

}]);