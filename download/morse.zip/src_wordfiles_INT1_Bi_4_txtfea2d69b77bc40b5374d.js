"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_Bi_4_txt"],{

/***/ "./src/wordfiles/INT1_Bi_4.txt":
/*!*************************************!*\
  !*** ./src/wordfiles/INT1_Bi_4.txt ***!
  \*************************************/
/***/ ((module) => {

module.exports = "WEAR AND TEAR \r\nVOLTS AND AMPS \r\nROCK AND ROLL \r\nLIVE AND LEARN \r\nPLAIN AND SIMPLE \r\nNOW AND THEN \r\nTO AND FRO \r\nMORE OR LESS \r\nPICK AND CHOOSE \r\nGIVE AND TAKE \r\n";

/***/ })

}]);