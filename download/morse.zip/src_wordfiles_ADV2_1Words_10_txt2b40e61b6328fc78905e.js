"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV2_1Words_10_txt"],{

/***/ "./src/wordfiles/ADV2_1Words_10.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/ADV2_1Words_10.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "reporter {construction|} \r\n{|reporter construction} \r\nartistic {paragraph|} \r\n{|artistic paragraph} \r\noffender {certainly|} \r\n{|offender certainly} \r\ncriteria {relationship|} \r\n{|criteria relationship} \r\nsupposedly {conservative|} \r\n{|supposedly conservative} \r\nawareness {specialty|} \r\n{|awareness specialty} \r\nconfusion {initiative|} \r\n{|confusion initiative} \r\nchildhood {complicated|} \r\n{|childhood complicated} \r\nprecisely {worldwide|} \r\n{|precisely worldwide} \r\nharassment {festival|} \r\n{|harassment festival} ";

/***/ })

}]);