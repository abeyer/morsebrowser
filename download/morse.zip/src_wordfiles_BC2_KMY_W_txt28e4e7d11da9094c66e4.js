"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC2_KMY_W_txt"],{

/***/ "./src/wordfiles/BC2_KMY_W.txt":
/*!*************************************!*\
  !*** ./src/wordfiles/BC2_KMY_W.txt ***!
  \*************************************/
/***/ ((module) => {

module.exports = "KEY \r\nMIC \r\nYES \r\nYAY \r\nANY \r\nLOW \r\nONE \r\nLAW \r\nCOST \r\nKEEP \r\nKNEW \r\nMIKE \r\nMISS \r\nBEEN \r\nACHY \r\nBLOW \r\nGREW \r\nPOOR \r\nFOUR \r\nLONG \r\nHIGH \r\nLAST \r\nGIRL \r\nLONE \r\nSEEM \r\nSEAT \r\nPULL \r\nLOST \r\nHELP \r\nKNOW \r\nHEAR \r\nHEAD \r\nWENT \r\nREST \r\nSTICK \r\nTRUCK \r\nTHIRD \r\nMAGMA \r\nMETAL \r\nMAGIC \r\nABBEY \r\nABYSM \r\nWHEEL \r\nPRESS \r\nOTHER \r\nBEGIN \r\nAGAIN \r\nNORTH \r\nTRACK \r\nTHROW \r\n\r\n";

/***/ })

}]);