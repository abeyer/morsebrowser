"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_LNP_json"],{

/***/ "./src/wordfiles/Fam_LNP.json":
/*!************************************!*\
  !*** ./src/wordfiles/Fam_LNP.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890,.?/","minWordSize":1,"maxWordSize":1,"practiceSeconds":120}');

/***/ })

}]);