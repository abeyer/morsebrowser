"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV1_1Words_02_txt"],{

/***/ "./src/wordfiles/ADV1_1Words_02.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/ADV1_1Words_02.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "custody {constitute|} \r\n{|custody constitute} \r\nmedium {crease|} \r\n{|medium crease} \r\nthough {episode|} \r\n{|though episode} \r\nanyway {season|} \r\n{|anyway season} \r\nbasement {admission|} \r\n{|basement admission} \r\nsuppose {banana|} \r\n{|suppose banana} \r\nbehavior {respondent|} \r\n{|behavior respondent} \r\nequation {cousin|} \r\n{|equation cousin} \r\ndirectly {fashion|} \r\n{|directly fashion} \r\ngovernment {private|} \r\n{|government private} ";

/***/ })

}]);